

int
main()
{
  int x = 10;
  volatile int y = x + 69;
  return 0;
}
